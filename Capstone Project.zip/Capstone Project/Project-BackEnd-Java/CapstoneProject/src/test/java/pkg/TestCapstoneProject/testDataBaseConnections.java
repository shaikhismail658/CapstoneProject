package pkg.TestCapstoneProject;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import pkg.CapstoneProject.DataBaseOperationsDAO;

class testDataBaseConnections {

	@Test
	public void testCopyData() {
		
		String url1 = "jdbc:mysql://localhost:3306/";
		String databasename1 = "QUAL";
		String url2 = "jdbc:mysql://localhost:3306/";
		String databasename2 = "PROD";
		
		DataBaseOperationsDAO db = new DataBaseOperationsDAO();
		String result = db.copyData(url1, databasename1, url2, databasename2);
		
		Assertions.assertEquals("true",result); 
	}	
}