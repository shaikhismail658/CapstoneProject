package pkg.CapstoneProject;

public interface DataTransferService 
{
	public String copyData(String url1, String databasename1, String url2, String databasename2) ;
	
}
