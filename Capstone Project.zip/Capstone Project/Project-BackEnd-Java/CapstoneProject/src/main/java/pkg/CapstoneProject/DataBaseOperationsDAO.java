package pkg.CapstoneProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.springframework.stereotype.Repository;

@Repository
public class DataBaseOperationsDAO {
	
	String username = "root";
	String password = "root";
	
	public String copyData(String url1, String databasename1, String url2, String databasename2) {
		DataBaseConnection db1 = new DataBaseConnection();
		DataBaseConnection db2 = new DataBaseConnection();
		
		String message = "";
		String [] tables = {"employee","department","admin"};
		try {		
			Statement st = db1.getMyStatement(url1, databasename1, username, password);			
		for (int i = 0; i < tables.length; i++) {
			String query1 = "select * from "+tables[i]+" ";
			System.out.println(query1);	
			ResultSet rs = st.executeQuery(query1);
			
			Connection con = db2.getMyConnection(url2, databasename2, username, password); 
			PreparedStatement ps1 = con.prepareStatement("insert into "+tables[i]+" values(?,?,?,?)");
			while (rs.next()) {	
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4));
			    ps1.setInt(1,rs.getInt(1));
			    ps1.setString(2,rs.getString(2));
			    ps1.setString(3,rs.getString(3));
			    ps1.setString(4,rs.getString(4));
			    ps1.execute();
			    message = "true";
			}
		}
		}catch(Exception e) {
			message = "false";		
			e.printStackTrace();
			return message;
		} finally {
			db1.closeConnection();
			db2.closeConnection();
		}
		return message;
	}
}