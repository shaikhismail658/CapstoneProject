package pkg.CapstoneProject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataTransferServiceImp implements DataTransferService{
	
	@Autowired
	DataBaseOperationsDAO dataBaseOperations;
	
	@Override
	public String copyData(String url1, String databasename1, String url2, String databasename2) 
	{
		return dataBaseOperations.copyData(url1, databasename1, url2, databasename2);			
	}
}
