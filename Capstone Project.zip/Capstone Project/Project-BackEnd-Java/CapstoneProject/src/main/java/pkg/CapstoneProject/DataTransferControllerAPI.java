package pkg.CapstoneProject;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataTransferControllerAPI {
	
	@Autowired
	DataTransferService dataTransferService;
	
	@GetMapping("/DataCopy")
	public String DataCopyDB(@QueryParam("url1") String url1, @QueryParam("databasename1") String databasename1,@QueryParam("url2") String url2, @QueryParam("databasename2") String databasename2) 
	{
		String msg = "";		
		return msg = dataTransferService.copyData(url1, databasename1, url2, databasename2);
	}
}