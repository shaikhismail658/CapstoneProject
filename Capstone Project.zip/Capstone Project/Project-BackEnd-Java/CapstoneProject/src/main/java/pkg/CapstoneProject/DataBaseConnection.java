package pkg.CapstoneProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBaseConnection {
	Connection con;
	Statement st;

	public DataBaseConnection() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}  catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Connection getMyConnection(String url, String databasename, String username, String password) throws Exception {
		try {
			con = DriverManager.getConnection(url + databasename, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			con=null;
			throw e;
		}
		return con;
	}

	public Statement getMyStatement(String url, String databasename, String username, String password) throws Exception  {
		try {
			st=this.getMyConnection(url,databasename, username, password).createStatement();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			st=null;
			throw e;
		}
		return st;	
	}
	
	public void closeConnection(){
	 if(con!=null) {
		 try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }	
	}
}