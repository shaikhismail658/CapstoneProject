import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http'
import { AppComponent } from './app.component';

@Injectable({
  providedIn: 'root'
})
export class AsyncdataService {

  constructor(private http:HttpClient) { }

  doLginService(url1,databasename1, url2,databasename2){  
    var link="http://localhost:8029/DataCopy?url1=" +url1+ "&databasename1=" +databasename1+ "&url2=" +url2+ "&databasename2=" +databasename2;
    return this.http.get(link,{headers : new HttpHeaders({ 'Content-Type': 'application/json' })});
  }
}
