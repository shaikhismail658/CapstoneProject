import { Component } from '@angular/core';
import { NgModule } from '@angular/core';
import { EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AsyncdataService} from './asyncdata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  title = 'CapstoneProject';
  url1="";
  databasename1="";
  url2="";
  databasename2="";

  constructor(private ser:AsyncdataService) { }

  ngOnInit(){ }

  CallServiceLogin()
  {
    this.ser.doLginService(this.url1, this.databasename1, this.url2, this.databasename2).subscribe(res => {  
      console.log(res);
      console.log(res.toString);
      if (res.toString() == "true" ) {
         document.getElementById('errorMsg').innerHTML = "Data is exported successfully";     
      } else{
        document.getElementById('errorMsg').innerHTML = "Source/Destination DB not valid";
      }  
    });  
  } 
}