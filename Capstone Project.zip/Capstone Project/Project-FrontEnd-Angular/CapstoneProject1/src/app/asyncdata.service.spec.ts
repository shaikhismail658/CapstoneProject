import { TestBed } from '@angular/core/testing';

import { AsyncdataService } from './asyncdata.service';

describe('AsyncdataService', () => {
  let service: AsyncdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AsyncdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
